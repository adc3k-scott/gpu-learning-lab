# MARLIE-COOL-001 Rev 1.0
## Marlie 2.5 MW block — cooling loop engineering (PG25 + FW)

**Scope:** Engineer the PG25 secondary loop, the FW primary loop, the plate-frame heat exchanger, the adiabatic fluid cooler, and cooling aux electrical load for the Marlie 2.5 MW block per Rev 3 of the block diagram. Reconcile against vendor RFQ call sheets for EVAPCO, Alfa Laval, and Grundfos.

**Status:** Engineering baseline. Vendor quotes still required to finalize selections and pricing.

---

## 1. Baseline thermal duty (from Rev 3 diagram)

| Item | Value | Notes |
|---|---|---|
| IT load (13× Vera Rubin NVL72 + IB + storage) | 2,500 kW | Primary design load |
| DLC fraction (PG25 via cold plates) | ~86% | 2,150 kW |
| Air fraction (recirc AHU via FW coil) | ~14% | 350 kW |
| Rack power rack losses (5× Delta 660 kW @ 98%) | 50 kW | Captured in PG25 via cold-plate heatsinks |
| PG25 pump heat to fluid | 20 kW | ~80% pump eff |
| FW pump heat to fluid | 25 kW | VFD-driven |
| Recirc AHU fan/motor heat to fluid | 25 kW | Munters DSS Pro |
| **Total heat to adiabatic cooler** | **~2,620 kW** | **~745 RT** |

**Plate HX design duty:** 2.6 MW nominal with ~8% margin over calculated 2.42 MW.
**Adiabatic cooler design duty:** 2.6 MW nominal (~750 RT), 15°F approach at 80°F WB.

---

## 2. PG25 secondary loop

Serves rack CDUs (primary side) — cold plates (secondary W45 DLC loop). Returns to plate HX for rejection to FW.

### 2.1 Thermal / hydraulic design point

| Parameter | Value |
|---|---|
| Fluid | Propylene glycol 25% v/v in water (PG25) |
| Supply temperature | 113°F (45°C) |
| Return temperature | 136°F (58°C) |
| ΔT | 23°F (12.8 K) |
| Mean fluid temperature | 124.5°F (51.3°C) |
| Density @ mean T | ~1,008 kg/m³ (SG 1.012) |
| Specific heat @ mean T | ~3.87 kJ/kg·K |
| Viscosity @ mean T | ~1.0 cP |
| Design duty | 2.6 MW (nominal, with margin) |
| **Design flow rate** | **~830 gpm** (per Q = ṁ·Cp·ΔT) |

> **Note on diagram value:** Rev 3 shows 780 gpm. At 780 gpm and 23°F ΔT, the loop only transfers 2.42 MW, which matches calculated duty but leaves no margin. For the Grundfos RFQ, spec **830 gpm** to hit the 2.6 MW nameplate with margin. Diagram should be updated to 830 gpm at next rev.

### 2.2 Pressure drop budget (PG25 circuit)

Loop is compact: plate HX — manifold — 13 NVL72 rack CDUs — return manifold — bag filter / air separator — back to plate HX.

| Component | ΔP (psi) | ΔP (ft of PG25) |
|---|---|---|
| Plate HX primary (hot) side — M15 at design flow | 10 | 22 |
| Distribution manifold + branch piping (DN125) | 6 | 13 |
| Rack CDU primary-side coil (13× in parallel) | 15 | 33 |
| Return piping + balancing | 5 | 11 |
| 40 µm bag filter + strainer | 4 | 9 |
| Control valve + fittings | 5 | 11 |
| **Total TDH** | **45 psi** | **~100 ft** |

> **Important:** The Grundfos call sheet specifies **5.5 bar (~180 ft)** — this is approximately **80% higher than needed**. 5.5 bar will land you a pump that's overpowered and runs far off its BEP curve, wasting ~8 kW and shortening seal life. **Spec 100 ft (3.0 bar)** instead. The diagram's 80 ft is at the low end of plausible; 100 ft gives real margin.

### 2.3 Pump selection (PG25)

Three pumps in parallel: **2 running + 1 standby (N+1)**. Each pump sized for 415 gpm at 100 ft TDH (half flow).

| Parameter | Value |
|---|---|
| Flow per pump (normal) | ~415 gpm (94 m³/hr) |
| Head | 100 ft TDH (~3.0 bar, ~30.5 m) |
| Fluid | PG25, SG 1.012 @ 51°C |
| Hydraulic power per pump | 415 × 100 × 1.012 / 3,960 = **10.6 hp** |
| Pump efficiency (CRE at BEP) | ~75% |
| Brake power per pump | 14.1 hp (10.5 kW) |
| Motor efficiency (NEMA Premium) | 94% |
| VFD efficiency | 97% |
| **Electrical input per pump** | **~11.5 kW** |
| **Electrical (2 running)** | **~23 kW** |
| Heat to PG25 fluid (2 running, brake power minus useful work) | ~21 kW |

**Recommended model:** Grundfos **CRE 90** series (~94 m³/hr at ~30 m is near BEP). Ask Premier Equipment to confirm. Seal package must be **EPDM-compatible with propylene glycol** (standard for CRE, but verify).

### 2.4 PG25 loop accessories (in the cooling cassette)

- 2.5 m³ buffer / expansion tank (PG25) with nitrogen blanket
- Automatic glycol feeder + makeup fluid reservoir (50 gal)
- 40 µm bag filter housing with ΔP switch
- Air separator (coalescing type)
- Expansion tank (diaphragm, sized for 10% of system volume at ΔT)
- System volume estimate: ~2,500 L (cassette manifolds + HX + 13× CDU secondaries)
- Instrumentation: T/P at 4 points, flow meter, conductivity, pH
- Leak detection cable in drip trays under all joints

---

## 3. FW primary loop

Serves plate HX cold side (PG25 heat rejection) + Munters DSS Pro recirc coil (air-side heat). Rejects to adiabatic cooler.

### 3.1 Thermal / hydraulic design point

| Parameter | Value |
|---|---|
| Fluid | Treated water (no glycol — outdoor loop is Louisiana, no freeze risk) |
| Supply temperature | 95°F (35°C) |
| Return temperature | 110°F (43°C) |
| ΔT | 15°F (8.3 K) |
| Mean fluid temperature | 102.5°F (39.2°C) |
| Design duty | 2.6 MW (rejection target) |
| **Design flow rate** | **~1,190 gpm** (per Q = 500 · gpm · ΔT) |

> **Note on diagram value:** Rev 3 shows 1,100 gpm. At 1,100 gpm × 15°F, the loop only moves 2.42 MW. Spec **1,190 gpm** to EVAPCO and Premier to cover full 2.6 MW nameplate. Alternatively, widen ΔT to 16.5°F at 1,100 gpm — but that raises return temperature and pushes approach to the adiabatic cooler, which is already tight at 80°F WB. **Stick with 15°F ΔT and bump flow to 1,190 gpm.**

### 3.2 Pressure drop budget (FW circuit)

Loop: FW pump — plate HX cold side (in parallel with Munters coil) — outdoor run to adiabatic cooler pad — cooler coil — return to pump. Assume 100 ft one-way outdoor piping, cooler elevated ~4 ft on pad.

| Component | ΔP (psi) | ΔP (ft H₂O) |
|---|---|---|
| Plate HX cold side — M15 at design flow | 10 | 23 |
| Munters AHU coil (parallel branch, sized smaller) | 6 | 14 |
| Piping to adiabatic cooler (100 ft × 2, DN150) | 3 | 7 |
| Adiabatic cooler coil (EAW-DA finned tube) | 10 | 23 |
| Control valves + balancing + fittings | 5 | 12 |
| Elevation + misc | 1 | 2 |
| **Total TDH** | **35 psi** | **~80 ft** |

> **Important:** The Grundfos call sheet specifies **3.3 bar (~108 ft)** — this is reasonable but slightly overspec. **80 ft is the engineered value.** If your outdoor piping run ends up longer than 100 ft one-way, or if the adiabatic cooler sits further from the cassette, revisit.

### 3.3 Pump selection (FW)

Three pumps in parallel: **2 running + 1 standby (N+1)**. Each sized for 595 gpm at 80 ft TDH (half flow).

| Parameter | Value |
|---|---|
| Flow per pump (normal) | ~595 gpm (135 m³/hr) |
| Head | 80 ft TDH (~2.4 bar, ~24.4 m) |
| Hydraulic power per pump | 595 × 80 × 1.00 / 3,960 = **12.0 hp** |
| Pump efficiency | ~76% |
| Brake power per pump | 15.8 hp (11.8 kW) |
| **Electrical input per pump** (motor + VFD) | **~12.9 kW** |
| **Electrical (2 running)** | **~26 kW** |
| Heat to FW fluid (2 running) | ~24 kW |

**Recommended model:** Grundfos **CRE 125** series (~135 m³/hr at ~25 m is in-band) — **NOT CRE 45** as on the call sheet. CRE 45 tops out at ~50 m³/hr (220 gpm), which means each pump would be at ~270% of its max flow. **That selection is wrong.**

Alternative: at 595 gpm per pump, a **Grundfos NK / NKE end-suction** pump is more efficient than vertical multistage. Ask Premier to quote both CRE 125 and NKE 80-200 or similar for comparison.

---

## 4. Plate-frame heat exchanger (Alfa Laval M15)

### 4.1 Sizing

| Parameter | Value |
|---|---|
| Duty | 2.6 MW (8,872,000 Btu/hr) |
| Hot side: PG25 in / out | 136°F / 113°F @ 830 gpm |
| Cold side: FW in / out | 95°F / 110°F @ 1,190 gpm |
| ΔT₁ (hot in − cold out) | 26°F |
| ΔT₂ (hot out − cold in) | 18°F |
| **LMTD (countercurrent)** | **21.8°F (12.1 K)** |
| Assumed U (water/PG25, clean, turbulent) | 3,500 W/m²·K |
| **Required area** | **Q / (U × LMTD) = 2,600,000 / (3,500 × 12.1) ≈ 61.5 m²** |

### 4.2 M15 confirmation

Alfa Laval M15 is a **mid-size gasketed plate HX**, rated up to ~500 m³/hr and well-suited to this duty:
- Our flows (188 m³/hr PG25, 270 m³/hr FW) are comfortably in-band
- M15 nominal plate area ~0.3 m² (varies by plate series — M15-M, M15-B, M15-BFG)
- **Estimated plate count: 205–240 plates** (depending on plate series and fouling allowance)

### 4.3 Material / gasket specification

| Item | Spec | Rationale |
|---|---|---|
| Plate material | **AISI 316L** | Confirmed — PG25 + treated water service, corrosion margin |
| Plate thickness | 0.5 mm (standard) | Pressure adequate |
| Gasket material | **EPDM** | Compatible with PG25 at 58°C peak; standard AL offering |
| Gasket attachment | Clip-on (ClipGrip) or glued | Clip-on preferred for field service |
| Design pressure | 10 bar (145 psi) minimum | Matches call sheet |
| Design temperature | 80°C (176°F) minimum | Covers 58°C + upset margin |
| Frame | Standard carbon steel, painted | Cassette is IP44 outdoor-rated but HX is indoor |
| Connections | DN150 (6") flanged, both sides | Matches pipe size for target flows |

**Expandability:** M15 frame can accept additional plates up to max length — request frame sized for **+30% plates** over design count so you can add capacity without replacing the frame.

---

## 5. Adiabatic fluid cooler (EVAPCO EAW-DA)

### 5.1 Sizing

| Parameter | Value |
|---|---|
| Duty | 2.6 MW (~745 RT) |
| Water in | 110°F |
| Water out | 95°F |
| Range | 15°F |
| Design wet bulb (Lafayette, 1% WB) | 80°F |
| Approach | 15°F (tight — drives unit size up) |
| Flow | ~1,190 gpm |
| Mode | Dry most of year; adiabatic wet mode above ~78°F WB |

### 5.2 Unit count

**EAW-DA Double Stack** single-unit capacity at 15°F approach and 80°F WB typically runs 300–500 tons per unit depending on coil length and fan count. At 745 tons duty, expect:

- **2 units likely**, sharing headers and controls
- Possibly 1 very large unit (extended model), but less common in this approach band
- **Action:** EVAPCO's selection report will pin this down. Ask specifically for single-unit options vs. 2-unit options with pro/con.

### 5.3 Electrical draw

| Item | kW |
|---|---|
| EC fans (VFD, ~10-12 fans across 2 units) | 70 |
| Spray pumps (wet mode only, 2 units) | 15 |
| Controls + sensors + drift eliminators heater | 5 |
| **Total** | **~90 kW** |

Matches diagram footer. 90 kW is the **wet-mode** value; dry-mode is ~70 kW (fans only, reduced speed at lower WB).

### 5.4 Water treatment / makeup

- Adiabatic pads use evaporative cooling only when WB > setpoint (~78°F)
- Estimated makeup water: 3–5 gpm during wet operation (Louisiana summer ~1,500 hrs/yr)
- **Annual water consumption: ~250,000–400,000 gallons** (tight estimate, confirm with EVAPCO)
- Treatment: basic softening + biocide; ask EVAPCO for Louisiana-specific recommendations (Vermilion basin water chemistry)
- Drain cycle management + conductivity controller required

---

## 6. Cooling auxiliary electrical load summary

### 6.1 Block cooling aux at 480V 3-phase (the Porch distribution)

| Load | kW | Notes |
|---|---|---|
| PG25 pumps (2 running + VFD) | 23 | 3× CRE 90, one standby |
| FW pumps (2 running + VFD) | 26 | 3× CRE 125 or NKE, one standby |
| Adiabatic cooler (fans + spray pumps) | 90 | 2× EAW-DA |
| Munters DSS Pro recirc AHU (fans + controls) | 25 | Air loop to sealed compute cassette |
| Makeup DOAS (desiccant wheel + fan + regen) | 15 | Positive-pressure OA only |
| Cooling cassette controls + BMS + instruments | 10 | Siemens S7-1500, sensors |
| Miscellaneous (lighting, heat trace, receptacles) | 10 | Porch / cassette aux |
| **Total cooling aux** | **~200 kW** | — |

Diagram footer shows 223 kW including Porch aux + SCR urea pump; this ~200 kW is cooling-system-only, with SCR urea allocation tracked under emissions.

### 6.2 Feeder sizing (cooling cassette from the Porch)

| Parameter | Value |
|---|---|
| Design load | 200 kW |
| Voltage | 480V 3-phase, 4-wire + ground |
| Power factor | 0.92 (inductive with VFD correction) |
| FLA | 200,000 / (√3 × 480 × 0.92) = **262 A** |
| Feeder breaker | 400 A (125% + harmonic / starting margin) |
| Wire size (Cu, THHN, 75°C) | 500 kcmil |
| Conduit | 3" RMC |

### 6.3 Critical aux BBU (ride-through)

Per Rev 3 diagram: **30-second BBU ride-through** for pumps + fans on genset trip.

| Critical load | kW |
|---|---|
| PG25 pumps (2 running) | 23 |
| FW pumps (2 running) | 26 |
| Adiabatic fans (at 75% speed ride-through) | 53 |
| Munters recirc AHU fans | 20 |
| Controls + BMS | 10 |
| **Total critical aux** | **~132 kW** |

BBU sizing for 30s at 132 kW: 1.1 kWh useful energy. Recommend **200 kVA / 5-min UPS** (Eaton 93PM or Schneider Galaxy VS equivalent) for 17 kWh nominal — oversized but gives real buffer and allows time for ATS to genset or orderly GPU rampdown if longer outage.

---

## 7. Corrections to vendor call sheets

Three items in your RFQ call sheets conflict with the engineered design. Fix these before the calls:

### 7.1 EVAPCO call sheet — OK as written
All parameters match the engineering. Call sheet correctly specifies 2.6 MW, 110–95°F, 80°F WB. No changes needed. One addition to ask: **"Can we run two smaller EAW-DA units in parallel with shared headers, or is one extended unit preferred at this approach?"**

### 7.2 Alfa Laval call sheet — two fixes

- **Hot-side flow:** Call sheet says ~780 gpm. Change to **~830 gpm** to match 2.6 MW duty with margin.
- **Cold-side flow:** Call sheet doesn't list cold-side flow explicitly. Add: **"~1,190 gpm water on cold side."**
- Everything else (materials, pressure, gasket) is correct as written.

### 7.3 Grundfos call sheet — three fixes

- **PG25 pump head:** Call sheet says 5.5 bar. Change to **3.0 bar (100 ft)**. 5.5 bar is ~80% over the engineered head and will land you an oversized pump.
- **FW pump model:** Call sheet says CRE-45 for water pumps. **This is wrong — CRE 45 tops out at ~220 gpm per pump.** At 595 gpm per pump (2 running at half flow), you need **CRE 125 minimum**, or an **end-suction NKE 80-200** which may actually be more efficient at this flow. **Ask Premier to quote both.**
- **FW pump flow:** Call sheet says 2,900 LPM total. Change to **~4,500 LPM (1,190 gpm total)**.
- **PG25 pump model:** Call sheet says CRE-64 — verify. At 415 gpm per pump (2 running at half flow), **CRE 90 is the better match**; CRE 64 is marginal at ~330 gpm peak. Ask Premier which BEP-aligns best at 94 m³/hr, 30 m TDH.

---

## 8. Open items (before procurement commit)

| # | Item | Owner | Blocker for |
|---|---|---|---|
| C-1 | EVAPCO selection report — confirm unit count (1 large vs. 2 smaller EAW-DA) | EVAPCO / ST | Cooling pad footprint |
| C-2 | Alfa Laval M15 selection report — plate count, series (M/B/BFG), lead time | Alfa Laval via HTS-LA | Cooling cassette interior layout |
| C-3 | Grundfos confirmation — CRE 90 vs. alternative for PG25; CRE 125 vs. NKE for FW | Premier / ST | Pump skid layout + power drop sizing |
| C-4 | Rack CDU pressure drop curve (actual, not assumed 15 psi) | Vertiv / CoolIT / Motivair | PG25 TDH final; may shift from 100 ft |
| C-5 | Munters DSS Pro FW coil ΔP + flow requirement | Munters | FW flow split between HX + coil |
| C-6 | Louisiana water chemistry for EAW-DA treatment plan | LUS water utility | EVAPCO treatment package |
| C-7 | Critical aux BBU vendor RFQ (Eaton 93PM, Schneider Galaxy VS, Vertiv Liebert) | ST | Porch BBU bus sizing |
| C-8 | Confirm rack CDU inlet spec — 45°C / 113°F is at the high end for some CDU families | NVIDIA ref design | PG25 supply temp hold |

---

## 9. Revision history

| Rev | Date | Change |
|---|---|---|
| 1.0 | 2026-04-21 | Initial engineering package against Rev 3 block diagram; reconciled vendor RFQ call sheets; flagged three sizing errors in Grundfos call sheet and one flow mismatch in Alfa Laval call sheet. |
