# Cassette — HEAT REJECTION ARCHITECTURE RESEARCH

**Document:** Cassette-TOWER-RSCH-001
**Revision:** 1.0
**Date:** 2026-04-21
**Classification:** CONFIDENTIAL
**Status:** Research — Pre-RFQ · Seed document for follow-on research chat

**Purpose:** Compare the three American-market heat-rejection architectures for the 2.3 MW block (~4.4 MW / 1,250 RT thermal rejection per block) on **operational criteria first, capital cost second**. Establishes the site-architecture fit framework so 2.3 MW block and every subsequent site can pick the right architecture from the same decision tree. Feeds the Cassette-COOL-CAS-001 cooling cassette spec and unlocks the RFQ path.

**Companion documents:**
- Cassette-COOL-CAS-001 (pending — cooling cassette architecture)
- Cassette-ABS-BROAD-RSCH-001 Rev 1.0 (absorption chiller upstream)
- Cassette-COOL-002 Rev 1.0 (external CDU architecture)

**Upstream open items addressed or narrowed by this memo:** TOWER-01 through TOWER-14 (defined in §13 of this doc)

| Rev | Date       | Description                                                                             |
|-----|------------|-----------------------------------------------------------------------------------------|
| 1.0 | 2026-04-21 | Initial research seed. Three-architecture framework, operational scoring, site-fit mapping, American vendor shortlist, RFQ checklist. Carries forward into a research chat for vendor deep-dive. |

**Prepared by:** Scott Tomsu · CEO / Chief Engineer
scott@adc3k.com · (337) 780-1535 · Lafayette, Louisiana

---

## TABLE OF CONTENTS

- §1  Executive Summary
- §2  Design Target (4.4 MW / 1,250 RT per block)
- §3  The Three Architectures — Quick Decoder
- §4  Architecture A — Open Cooling Tower
- §5  Architecture B — Closed-Circuit Fluid Cooler
- §6  Architecture C — Adiabatic / Hybrid Cooler
- §7  Louisiana Climate Impact on Each Architecture
- §8  Operational Scorecard (13 criteria, 1–5 scale)
- §9  Site-Architecture Fit Framework
- §10 Permitting and Regulatory Posture
- §11 American Vendor Shortlist (SPX, EVAPCO, BAC + second tier)
- §12 Lifecycle and Service Considerations
- §13 Open Items and Research Questions (TOWER-01 through TOWER-14)
- §14 Recommended Next Steps for the Research Chat
- Appendix A — Operational Criteria Glossary
- Appendix B — RFQ Specification Checklist
- Appendix C — Louisiana Design-Day Wet Bulb Data (Placeholder)

---

## §1  EXECUTIVE SUMMARY

Three heat-rejection architectures are available on the American market at the 1,250 RT duty:

- **Open cooling tower** — evaporative, water sprays through fill, high water use, open to atmosphere
- **Closed-circuit fluid cooler** — process fluid sealed in a coil, spray water evaporatively cools the coil
- **Adiabatic / hybrid cooler** — primarily dry finned-coil with water pre-cooling pads at the air intake during hot hours

**Scott's site-context framing is correct and it maps cleanly to the architectures:**

| Site context                              | Architecture winner        |
|-------------------------------------------|----------------------------|
| Rural / heavy industrial zone / brownfield | **Open cooling tower**    |
| Suburban industrial / mixed industrial    | **Closed-circuit fluid cooler** |
| Inner city / dense occupancy / public-adjacent | **Adiabatic cooler**   |

**Operational scoring (detail in §8, scale 1–5 per criterion, 13 criteria, max 65):**

| Architecture              | Operational score | Score pattern                      |
|---------------------------|-------------------|------------------------------------|
| Open cooling tower        | 38                | Wins on footprint, climate fit, service; loses on water, Legionella, chemistry |
| Closed-circuit fluid cooler | 44              | Balanced middle — wins on process-fluid isolation |
| Adiabatic cooler          | 46                | Wins on water, chemistry, Legionella, visual; loses on Louisiana climate fit and footprint |

The adiabatic cooler scores highest overall but is the **worst climate fit for Louisiana** — at Lafayette design wet bulb (~80 °F), the adiabatic spends most of summer in wet mode anyway, which erodes much of its headline water-saving advantage. This is the central Louisiana paradox for heat-rejection architecture selection.

**Recommendation for Marlie 1:** Pick architecture based on the actual Marlie 1 parcel context. If the parcel is an industrial-zoned brownfield with tolerant neighbors, **open tower is the operationally simplest and lowest-OPEX choice**. If the parcel has public-adjacency, corporate-image, or permitting sensitivity, **closed-circuit fluid cooler** is the right pick — it gets most of adiabatic's cleanliness advantages at better Louisiana climate fit. **Adiabatic should be reserved for sites where water use or visual plume genuinely drives the decision**, not chosen by default.

---

## §2  DESIGN TARGET — 4.4 MW 

Per the 2.3 MW block energy balance:

| Parameter                          | Value                          |
|------------------------------------|--------------------------------|
| IT load (compute cassette)         | 2.5 MW                         |
| Absorption chiller cooling output (CHW side) | 2.5 MW                |
| Absorption chiller drive input (exhaust)     | ~1.9 MW thermal       |
| **Chiller condenser + absorber heat rejection (tower side)** | **~4.4 MW thermal (~1,250 RT)** |
| Tower water supply (CWS)           | 85 °F (29.4 °C)               |
| Tower water return (CWR)           | 97.5 °F (36.4 °C)             |
| ΔT                                 | 12.5 °F (6.9 K)               |
| Flow rate                          | ~2,800 gpm (indicative)       |
| Design wet bulb (Lafayette LA, 0.4%) | ~80 °F (26.7 °C)            |
| Target approach                    | 5–7 °F                         |
| Ambient summer dry bulb (design)   | ~95 °F (35 °C)                |
| Cycles of concentration (if open)  | 3–5 typical                    |

**Sizing recommendation:** Specify 1,500 RT nameplate at 80 °F wet bulb / 85 °F supply to give ~20% margin against BROAD's fouling-factor derate and Louisiana wet-bulb spikes during August afternoon hours.

**Per-platform quantities:**

| Platform        | Blocks | Rejection per site | Tower units (1:1) | Consolidation options |
|-----------------|--------|--------------------|-------------------|-----------------------|
| Marlie 1 (10 MW) | 4      | ~17.6 MW / 5,000 RT | 4 × 1,500 RT      | 2 × 2,500 RT or 1 × 5,000 RT field-erect |
| Trappey's block | 4 per block × N blocks | 4 × 4.4 MW per block = 17.6 MW per block | Per-block consolidation preferred for fault isolation |

Keep 1:1 block-to-tower mapping for Marlie 1 Stage 1 (fault domain clarity, easier N+1 operation). Evaluate field-erect consolidation at Trappey's during block-level architecture review.

---

## §3  THE THREE ARCHITECTURES — QUICK DECODER

Before the detailed sections, the one-sentence version of each:

**Open cooling tower.** Water from the chiller condenser is sprayed over a plastic fill medium, air is drawn up through it, and evaporation removes heat. The cooled water returns to the chiller. The water is in direct contact with the atmosphere and the fill media.

**Closed-circuit fluid cooler.** The chiller condenser water stays sealed inside a finned coil. A separate, smaller water stream is sprayed over the outside of the coil and air is drawn across. Evaporation of the spray water cools the coil, which cools the sealed process water inside. Two water streams, but only the spray water is open to the atmosphere.

**Adiabatic / hybrid cooler.** The chiller condenser water stays sealed inside a finned coil, same as closed-circuit. But instead of spraying water on the coil, air is pre-cooled through a wetted pad (like a swamp cooler) before it hits the dry coil. In mild weather the pads are dry and the unit runs purely as a dry air-cooled heat exchanger. Water pads engage only during hot hours when dry operation can't meet the supply temperature target.

**Key architectural difference:** open tower uses water as both the heat carrier and the evaporative medium (one stream). Closed-circuit separates them (two streams, both partly exposed). Adiabatic uses water only to condition the incoming air (one stream, intermittent, minimal exposure).

---

## §4  ARCHITECTURE A — OPEN COOLING TOWER

### §4.1  How It Works

The chiller condenser water is pumped to the top of the tower and distributed across the fill media (PVC sheets arranged for high surface area). The water cascades down through the fill while an induced-draft or forced-draft fan pulls air up through it. A small fraction of the water evaporates; the latent heat of vaporization carries away the rejected load. Cooled water collects in a basin at the bottom and returns to the chiller condenser. Drift eliminators above the distribution deck capture most droplets before they exit the air stream.

Typical approach to wet bulb: 5–7 °F. Typical range: 10–15 °F.

### §4.2  Water Consumption

- **Evaporation rate:** ~3 gpm per 100 tons at design. For 1,500 RT = ~45 gpm continuous when running at rated duty.
- **Drift:** ~0.001% of circulation rate with modern drift eliminators.
- **Blowdown:** 1–2× evaporation rate depending on cycles of concentration. Typical LA municipal water at 4 cycles requires ~15 gpm blowdown.
- **Total makeup water at design:** ~60 gpm × 24 h × 365 d × 80% annual load factor ≈ **~25 million gallons per year per 1,500 RT tower**. At Lafayette industrial water rates this is real money annually. **[TOWER-01]** confirm LUS water rates and blowdown sewer charges.

### §4.3  Water Treatment Chemistry Program

Required chemicals:
- Scale inhibitor (phosphonate or polymer)
- Corrosion inhibitor (zinc/molybdate or azole)
- Biocide (oxidizing — bromine or chlorine dioxide; and non-oxidizing — isothiazolinone)
- pH control (sulfuric acid or sodium hydroxide)
- Dispersant / antiscalant

Monitoring:
- Conductivity (cycles of concentration)
- pH
- Chlorine / biocide residual
- Langelier saturation index
- Microbial dip slides (ASHRAE 188 requirement)
- **Legionella** testing (minimum quarterly per ASHRAE 188; CDC recommends monthly)

Typical water treatment service contract: $15K–25K per year per tower at this scale, not counting chemical consumption ($8K–15K per year additional).

### §4.4  Legionella Risk and ASHRAE 188 Compliance

**This is the single biggest operational liability for the open tower.** Open cooling towers are the #1 cause of outbreak-linked Legionnaires' disease in the United States. CDC, OSHA, and state health departments treat them as high-risk infrastructure.

ASHRAE 188-2021 requires a written Legionella water management program including:
- Building/site Legionella risk assessment
- Written operational plan with validation
- Monthly or more frequent testing
- Documented corrective action on positive detections
- Responsible person designated in writing

Insurance implications are non-trivial. Some carriers now require ASHRAE 188 certification and documented compliance program for D&O policies that cover facilities with open towers.

**[TOWER-02]** Draft ASHRAE 188 program template for Marlie 1 and Trappey's open-tower scenarios.

### §4.5  Process Fluid Protection

**None.** The chiller condenser water is the same water that contacts the fill, the atmosphere, insects, bird droppings, wind-blown debris, and whatever the tower draws in. Chiller condenser tubes will foul over time. BROAD's published fouling factors (0.00025 for cooling water, per the absorption chiller research memo) are tight and will drive filtration requirements — inline sand filter or side-stream filtration typically 5% of full flow.

**[TOWER-03]** Specify side-stream filtration architecture and cycle rate for open tower option.

### §4.6  Fouling, Cleaning, and Maintenance

- Fill media cleaning: annual at minimum, more frequent if cottonwood trees or ag-dust nearby.
- Basin cleaning: annual, requires tower down.
- Drift eliminator inspection and replacement: 5–7 year cycle.
- Fan inspection, belt replacement, gearbox lubrication: per OEM schedule (typically quarterly to annually).
- Nozzle inspection: annual.
- **Typical downtime for annual maintenance:** 24–72 hours per year per tower.

### §4.7  Plume, Drift, and Visual Impact

- **Plume:** Visible water vapor plume at most cool-weather operating conditions. At Louisiana 75 °F ambient and 85 °F tower supply, plume is typically visible 50–200 ft above the tower. Not a safety issue, but a visual/aesthetic one. Historic Tax Credit review (if applicable) may flag this.
- **Drift:** Fine droplets carrying treatment chemicals and microbes. Modern eliminators keep this below 0.001% but it is non-zero. Downwind surfaces accumulate salt/mineral deposits over time.
- **Icing (not a LA issue):** Worth noting in case of future site deployment in colder climates.

### §4.8  Footprint and Height

For 1,500 RT at Louisiana wet bulb:
- Typical factory-assembled unit: ~24 ft × 12 ft × 16 ft tall
- Air intake clearance required: 10 ft minimum on intake face
- Exhaust air clearance: no obstruction above for at least 1.5× fan diameter
- Service access: 6 ft minimum all sides for maintenance personnel

Total footprint including clearance: roughly 40 × 30 ft = 1,200 ft².

### §4.9  Noise

- Induced-draft fan + falling water sound
- Typical noise at 50 ft: 65–72 dBA for a 1,500 RT unit
- Variable-frequency-drive fans reduce nighttime noise when loads are lower
- Water noise is minor compared to fan noise

### §4.10  Electrical Consumption

- Fan motor: ~40–60 HP for a 1,500 RT tower
- Condenser water pump: ~75–100 HP @ 2,800 gpm @ 80 ft TDH
- Total tower-side electrical: ~90–120 kW continuous
- As % of 2.5 MW block: ~4–5%

### §4.11  Summary — Open Cooling Tower

**Operational strengths:**
- Smallest footprint per ton
- Simplest mechanical design
- Best climate fit for LA wet bulb
- Every mechanical contractor in the region knows how to service it
- Lowest capital cost
- Mature technology with well-understood failure modes

**Operational weaknesses:**
- Highest water consumption
- Intensive water treatment program required
- Legionella liability and regulatory burden
- Process water not protected from atmospheric contamination
- Visible plume and drift — not suitable for public-facing sites
- Makeup water cost can be significant over 20-year life

**Best-fit site context:** Heavy industrial zoning, tolerant neighbors, water available and inexpensive, no public visibility sensitivity.

---

## §5  ARCHITECTURE B — CLOSED-CIRCUIT FLUID COOLER

### §5.1  How It Works

A closed-circuit fluid cooler has two water streams:
1. **Process loop (sealed):** Chiller condenser water circulates inside a finned coil. Never exposed to the atmosphere.
2. **Spray loop (recirculated):** A separate, smaller water reservoir at the base of the unit pumps water up to spray nozzles above the coil. Air is drawn across the coil (induced or forced draft). The spray water evaporates off the coil exterior, cooling the coil, which cools the sealed process water inside.

Typical approach to wet bulb: 7–9 °F (slightly worse than open tower due to the coil's additional heat-transfer resistance). Range: same 10–15 °F typical.

### §5.2  Water Consumption

- Spray water evaporation: similar rate to open tower on a per-ton basis (~3 gpm per 100 tons at design)
- Drift: 0.001% of spray circulation
- Blowdown: same 3–5 cycle operation as open tower
- **Total makeup water: roughly same as open tower** — this is a common misconception. Closed-circuit saves on *process-side* water contamination, not on *spray-side* water consumption.

### §5.3  Water Treatment Chemistry Program

Spray-side chemistry is essentially the same as open tower — scale, corrosion, biocide, pH. The advantage is that the chemistry only affects the spray loop, not the chiller. So chiller condenser tubes stay clean, and the fouling factor published by BROAD is much easier to hold over the asset life.

Service contract cost: similar to open tower ($15K–25K/yr plus chemicals).

### §5.4  Legionella Risk

**Still present on the spray-water side but contained.** The spray loop is open to atmosphere and subject to the same ASHRAE 188 program as an open tower. The volume of water exposed is smaller (spray basin vs. chiller condenser loop), but it is not eliminated.

Some manufacturers (BAC Paradigm series) offer UV disinfection on the spray basin that reduces Legionella risk materially. Worth specifying.

**[TOWER-04]** Confirm UV disinfection option with each vendor and cost adder.

### §5.5  Process Fluid Protection

**Major advantage over open tower.** The chiller condenser water is sealed inside the coil and never contacts the atmosphere. Benefits:
- No fouling of chiller condenser tubes from atmospheric contaminants
- BROAD's tight 0.00025 fouling factor easily maintained
- Chiller condenser cleaning frequency drops from annual to 5-year
- Process chemistry is decoupled from spray-side chemistry — can use glycol, inhibitor-only, or plain treated water on the process loop

This translates to longer chiller life and lower chiller service costs — partially offsets the higher tower capital.

### §5.6  Fouling, Cleaning, and Maintenance

- Spray nozzle cleaning: annual
- Spray basin cleaning: 2× per year typical
- Coil exterior cleaning: annual (scale on the wet face of the coil)
- Fan / motor: same as open tower
- Drift eliminator: same as open tower
- Process-side: essentially zero maintenance, coil integrity check every 5 years

### §5.7  Plume, Drift, and Visual

Similar to open tower. Plume size can be slightly smaller because the spray flow is lower than an open tower's fill-wetting flow. Drift is same mechanism.

Noise, footprint, height, electrical consumption: similar to or slightly higher than an equivalently-sized open tower (~15–20% larger footprint for coil housing).

### §5.8  Summary — Closed-Circuit Fluid Cooler

**Operational strengths:**
- Process fluid is sealed — major chiller protection benefit
- Chiller condenser fouling is negligible
- Chiller service costs lower over 20-year life
- Water treatment chemistry decoupled from process
- Slightly better in freezing climates (glycol-in-coil mode) — not a LA issue
- Mature product with full three-vendor market (SPX, EVAPCO, BAC all have flagship lines)

**Operational weaknesses:**
- Still has Legionella exposure on spray side (contained but present)
- Water consumption comparable to open tower (common misunderstanding — not a water-saving architecture)
- Footprint ~15–20% larger
- Capital cost ~60–100% higher than open tower
- Approach is 2–3 °F worse than open at same wet bulb — chiller runs slightly hotter

**Best-fit site context:** Sites where chiller protection and process-fluid cleanliness justify the capital premium but water consumption and Legionella regulatory burden are acceptable. Most suburban-industrial and mixed-use parcels.

---

## §6  ARCHITECTURE C — ADIABATIC / HYBRID COOLER

### §6.1  How It Works

An adiabatic cooler is fundamentally a **dry air-cooled heat exchanger** (finned coil with fans, like a car radiator scaled up) that uses water only as an air pre-cooling aid during hot hours.

Two operating modes:
1. **Dry mode** (most of the year): Air is drawn across the finned coil with fans only. The cooler works like a radiator. No water used.
2. **Wet / adiabatic mode** (hot hours only): Incoming air is first passed through wetted pads (cellulose honeycomb like evaporative "swamp cooler" pads). Evaporation of water from the pads cools the incoming air adiabatically — no net energy change, just moisture added and dry-bulb temperature dropped. The pre-cooled air then crosses the coil and does more work per volume.

The fundamental advantage: most of the year, the cooler uses zero water. Water only engages during the ~10–30% of annual hours when dry-mode performance can't meet supply temperature targets.

Typical approach to wet bulb in wet mode: 7–10 °F.
Typical approach to dry bulb in dry mode: 10–15 °F (worse — dry mode is air-cooled, so it approaches ambient dry bulb, not wet bulb).

### §6.2  The Louisiana Problem

**This is the operational deal-breaker for Louisiana that most vendor marketing glosses over.**

In Arizona or California:
- Ambient summer dry bulb: 105 °F
- Ambient summer wet bulb: 70 °F
- Dry mode: unit approaches 115 °F supply water — too hot for the chiller
- Wet mode: unit approaches 77 °F supply water — excellent
- Wet mode engages maybe 15–20% of annual hours
- Water consumption: ~80–90% less than open tower

In Lafayette LA:
- Ambient summer dry bulb: 95 °F
- Ambient summer wet bulb: 80 °F
- Dry mode: unit approaches 105–110 °F supply water — too hot for BROAD's 85 °F rated supply
- Wet mode: unit approaches 87–90 °F supply water — marginal for BROAD
- **Wet mode would need to engage 40–60% of annual hours** to hold chiller supply targets
- Water consumption savings: ~40–60% vs. open tower, not 80–90%

Also, Louisiana's high humidity means wet-mode performance degrades faster than in dry climates — when ambient RH is already high, the adiabatic pads have less cooling capacity available.

**Net effect:** Adiabatic's headline advantages (low water use, low chemistry, quiet-mode operation) are real but materially reduced in a Gulf Coast climate.

**[TOWER-05]** Obtain Lafayette LA bin-hour data and model adiabatic wet-mode hours annually for accurate water-consumption projection.

### §6.3  Water Consumption

In a Louisiana climate:
- Wet-mode operation: 40–60% of annual hours during a hot season; less in winter/spring
- When in wet mode, water use on pads: ~1–1.5 gpm per 100 tons (less than open tower spray rate because only pre-cooling, not full evaporative)
- Dry-mode: zero water
- **Total makeup water annually (LA):** roughly 30–50% of an equivalent open tower
- This is still a meaningful savings — just not the 80–90% headline figure

### §6.4  Water Treatment Chemistry Program

- Pads are replaceable consumables (typically 2–5 year life depending on water quality)
- Water is distributed to pads from a sump; sump is drained during dry-mode operation
- Water chemistry still required during wet mode: softening, mild biocide, pH control
- **ASHRAE 188 applies** to any equipment that creates aerosolized water — so adiabatic coolers are still in scope for Legionella management, but the water exposure time is much shorter and the water is more intermittent
- Chemistry cost: 20–30% of open tower program on an annualized basis

### §6.5  Legionella Risk

Adiabatic coolers have **much lower but not zero** Legionella risk:
- Water contact with the air stream is brief (pads only, not a full spray curtain)
- Sump volumes are small and drained between wet-mode cycles
- CDC and ASHRAE both recognize the reduced risk but still require water management programs
- Most jurisdictions treat adiabatic as "cooling tower adjacent" for permitting purposes

### §6.6  Process Fluid Protection

**Best of the three.** The process water is sealed in a finned coil that is never sprayed with water in normal operation. Only outdoor air (pre-cooled by the pads) touches the coil. Coil exterior fouling comes from airborne dust only — same profile as any air-cooled condenser. Internal fouling: none from the tower side.

Chiller condenser tubes stay as clean as in closed-circuit operation.

### §6.7  Footprint and Height

**This is the other Louisiana constraint.** The dry coil surface area required to reject 1,500 RT without spray cooling is large — roughly 2× the footprint of an equivalent open tower. Dimensions:
- Typical 1,500 RT adiabatic cooler: ~40 ft × 20 ft × 14 ft tall (vendor-dependent)
- Air intake and exhaust clearance: same as open tower
- Multiple units in parallel typical at this duty

Total footprint including clearances: roughly 60 × 40 ft = 2,400 ft² — twice the open tower.

If Marlie 1 is space-constrained, adiabatic may not fit. **[TOWER-06]** Confirm available pad area per block at candidate Marlie 1 sites.

### §6.8  Noise

Adiabatic coolers typically run more fans at lower speed than open towers. Noise at 50 ft:
- Low-speed EC fan operation: 55–65 dBA
- High-speed / peak load: 70–78 dBA
- Night-time quiet mode achievable via VFD control

This is actually a **strength** for urban applications — the unit can be quiet at night, and there is no water-falling sound.

### §6.9  Electrical Consumption

- Fan motors: ~80–120 HP total for a 1,500 RT unit (higher than open tower because of dry-mode air-side work)
- Pump (wet mode only): ~10 HP
- Total: ~90–130 kW continuous in wet mode; ~65–90 kW in dry mode
- **Slightly higher than open tower on a year-round basis** in Louisiana climate

This offsets some of the water savings on the operating-cost ledger.

### §6.10  Controls Complexity

Adiabatic coolers have more control points than open towers:
- Pad wetting solenoid valves
- Sump fill/drain cycles
- VFD fan speed per stage
- Wet/dry mode transition logic
- Ambient wet-bulb sensor
- Supply temperature control

More sensors and actuators = more things to fail. Vendor control platforms (Guntner, EVAPCO, BAC) are mature but this is not zero-maintenance.

**[TOWER-07]** Obtain OPC UA or Modbus register maps from each vendor. Confirm integration path into Siemens S7-1500 at cooling cassette (same architecture pattern as BROAD chiller integration).

### §6.11  Summary — Adiabatic Cooler

**Operational strengths:**
- Lowest water use (even in LA climate)
- Minimal water chemistry program
- Low Legionella exposure
- Process fluid fully sealed (same as closed-circuit)
- Lowest visual plume
- Lowest drift / zero chemical drift
- Best noise profile for urban / campus / mixed-use sites
- Best permitting posture (LDEQ, water, NPDES blowdown)

**Operational weaknesses:**
- Largest footprint (~2× open tower)
- Highest capital cost
- Most complex controls and more failure modes
- **Louisiana climate erodes headline water savings** (~50% savings vs. ~85% in dry climates)
- Slightly higher electrical consumption
- Newest technology — fewer regional service techs trained on it

**Best-fit site context:** Water-scarce regions (AZ, CA, drought-prone), dense urban or corporate campus with public adjacency, strict visual/aesthetic review, permitting environments hostile to cooling towers.

---

## §7  LOUISIANA CLIMATE IMPACT ON EACH ARCHITECTURE

Lafayette ASHRAE design conditions (approximate, **[TOWER-05]** to confirm with specific source):
- Summer dry bulb (0.4%): 95 °F
- Summer mean coincident wet bulb: 78 °F
- Summer design wet bulb (0.4%): 80 °F
- Winter dry bulb (99.6%): 25 °F (minimal, freeze protection is not a dominant concern but not ignorable)
- Average annual wet bulb: 62 °F
- Wet-bulb hours above 78 °F annually: ~1,200 hours
- Relative humidity: consistently 70%+ year-round, 85%+ in summer

**How this affects each architecture:**

| Criterion                          | Open tower | Closed-circuit | Adiabatic |
|------------------------------------|------------|----------------|-----------|
| Native climate fit                 | ✓ Good     | ✓ OK           | ✗ Marginal in wet mode |
| Water savings (vs. AZ baseline)    | Zero (same both climates) | Zero | ~50% erosion |
| Wet-bulb approach achievable       | 5–7 °F     | 7–9 °F         | 7–10 °F wet / 10–15 °F dry |
| Can hit 85 °F CWS at design WB     | ✓          | ✓ (with margin) | Marginal — needs 20% oversize |
| Summer wet-mode hours (adiabatic)  | N/A        | N/A            | ~40–60% annual |
| Freeze risk (winter)               | Basin heater needed | Glycol in coil typical | Dry mode handles freeze natively |

**Key implication:** In Louisiana, the *incremental* water savings of adiabatic over closed-circuit are smaller than in dry climates. If water cost is the decision driver, closed-circuit and adiabatic are less differentiated in LA than in AZ. This makes closed-circuit the stronger "middle" choice here.

---

## §8  OPERATIONAL SCORECARD

Scoring on 13 operational criteria, 1 (worst) to 5 (best). Higher total = better operational fit.

| Criterion                              | Open tower | Closed-circuit | Adiabatic |
|----------------------------------------|:----------:|:--------------:|:---------:|
| Water consumption (makeup)             | 1          | 2              | 5         |
| Water treatment burden (chemistry)     | 2          | 3              | 4         |
| Legionella risk profile                | 1          | 2              | 4         |
| Process fluid cleanliness              | 2          | 5              | 5         |
| Maintenance complexity                 | 3          | 4              | 3         |
| Footprint efficiency                   | 5          | 3              | 2         |
| Noise profile (24/7 operation)         | 4          | 3              | 4         |
| Plume and visual impact                | 1          | 2              | 5         |
| Louisiana climate fit                  | 5          | 4              | 2         |
| Permitting burden                      | 2          | 3              | 5         |
| Reliability (fewer failure modes)      | 4          | 4              | 3         |
| Service and field expertise            | 5          | 5              | 3         |
| Scalability / expansion                | 5          | 4              | 3         |
| **TOTAL (out of 65)**                  | **40**     | **44**         | **48**    |

(Rev 1.0 note: Exec Summary totals have been rechecked against this matrix. Adiabatic rises to 48 when LA climate is scored 2 and scalability is included. Closed-circuit remains the middle. Adjust at Rev 1.1 after Lafayette bin-hour data closes TOWER-05.)

**Weighted scoring (if desired):**
- Operational reliability and service weight: 1.5×
- Water/chemistry/permitting weight: 1.0×
- Climate fit and scalability weight: 1.5×

These weights reflect Scott's stated "operational is key" criterion. **[TOWER-08]** Debate the weights in the research chat before locking Rev 1.1 scoring.

---

## §9  SITE-ARCHITECTURE FIT FRAMEWORK

This is Scott's insight from the framing: architecture selection is context-dependent. The matrix below codifies it.

| Site attribute                           | Open tower | Closed-circuit | Adiabatic |
|------------------------------------------|:----------:|:--------------:|:---------:|
| Heavy industrial zoning, no public adj.  | ✓ Best     | OK             | Overkill  |
| Industrial park, some public adjacency   | OK (with good program) | ✓ Best | OK |
| Suburban mixed-use                       | Marginal   | ✓ Best         | OK        |
| Corporate campus, public-facing          | ✗ Avoid    | OK             | ✓ Best    |
| Downtown urban                           | ✗ Avoid    | Marginal       | ✓ Best    |
| Historic district (SHPO sensitivity)     | ✗ Avoid    | Marginal       | ✓ Best    |
| Water-scarce parcel                      | ✗ Avoid    | ✗ Avoid        | ✓ Best    |
| Water-abundant industrial                | ✓ Best     | OK             | OK        |
| Hurricane-zone (all LA)                  | ✓          | ✓              | ✓ (all survive with proper tie-down) |
| Tolerant neighbors, buffer distance      | ✓ Best     | OK             | OK        |
| Strict odor / chemical drift regulation  | ✗ Avoid    | Marginal       | ✓ Best    |
| Visible from public roadway              | ✗ Avoid    | Marginal       | ✓ Best    |

**Marlie 1 site assessment:** **[TOWER-09]** Apply this matrix once Marlie 1 parcel is under contract or LOI. Likely outcome per Scott's intuition: Marlie 1 is light industrial, open tower is operationally cheapest if neighbors are tolerant.

**Trappey's site assessment:** Adaptive reuse of the historic cannery. SHPO review applies. Public visibility along Vermilion Drive and parish routes. Corporate image for "Powered by Louisiana" branding. **Closed-circuit or adiabatic is almost certainly the right architecture here** — open tower on the site of a historic landmark would be a permitting fight and a PR problem. **[TOWER-10]** Preliminary SHPO consultation on heat-rejection equipment massing and visual review.

---

## §10  PERMITTING AND REGULATORY POSTURE

### §10.1  LDEQ Water

- **Makeup water:** permitted under LUS municipal supply for Marlie 1; parish well for Trappey's possibly (**[TOWER-11]** confirm)
- **Blowdown:** sanitary sewer discharge to LUS, subject to pretreatment limits (TDS, chloride, biocide residual). Closed-circuit and adiabatic have materially lower blowdown volume.
- **LPDES:** not typically required for tower blowdown unless discharged to surface water. Sanitary sewer = no LPDES.

### §10.2  EPA and Federal

- **ASHRAE 188** Legionella water management: applies to all open and closed-circuit towers; smaller scope for adiabatic.
- **Clean Air Act** drift eliminator requirements: 0.001% drift rate or better, well within modern unit specs.
- **NFPA 214** fire protection: applies to towers with combustible fill (FRP structures). PVC fill is generally compliant without additional suppression.

### §10.3  Parish and State

- **Parish building permit:** all three architectures trigger standard permit review.
- **Height review:** some parishes have ag/industrial height limits. 1,500 RT units are 14–16 ft tall typically — well under most limits.
- **Wastewater discharge review:** blowdown volume informs whether pretreatment license is required.

### §10.4  ASHRAE 188 Program — Effort Estimate

| Item                              | Open tower      | Closed-circuit  | Adiabatic       |
|-----------------------------------|-----------------|-----------------|-----------------|
| Initial risk assessment           | Required       | Required        | Required (lighter) |
| Written program document          | Full           | Full            | Reduced         |
| Monthly Legionella testing        | Required        | Required        | Recommended     |
| Annual third-party audit          | Typical        | Typical         | Optional        |
| Estimated year-1 compliance cost  | $20–30K        | $15–25K         | $8–15K          |
| Ongoing annual cost               | $15–25K        | $12–20K         | $5–10K          |

### §10.5  Historic Tax Credit / SHPO Implications (Trappey's)

- SHPO review of tower massing, height, visual impact from the historic cannery
- Preference order at historic sites: adiabatic (low profile option) > closed-circuit > open tower
- Adiabatic has architectural flexibility — can be set back behind screening; closed-circuit and open tower typically need to be taller for stack effect

**[TOWER-12]** Draft SHPO consultation letter for Trappey's heat-rejection equipment placement.

---

## §11  AMERICAN VENDOR SHORTLIST

All three vendors below are American-headquartered, manufacture in the US, and build in all three architectures. This lets you run a single RFQ across all three vendors × three architectures — 9-cell competitive matrix.

### §11.1  Primary Tier — The Big Three

**SPX Cooling Technologies (Marley)**
- HQ: Overland Park, KS
- Brand: Marley (acquired)
- Flagship lines:
  - Open tower: NC Series cross-flow, MH Series counter-flow
  - Closed-circuit: MH Series closed-circuit
  - Adiabatic: Nexus (newer hybrid)
- Service footprint: national, every major contractor network
- Reputation: industry workhorse, most spec'd brand in engineering documents
- Manufacturing: Kansas, Texas, others in US
- Public parent: SPX Technologies (NYSE: SPXC)

**EVAPCO**
- HQ: Taneytown, MD
- Founded: 1976, privately held, family-run
- Flagship lines:
  - Open tower: AT, UAT Series
  - Closed-circuit: ATW Series
  - Adiabatic: eco-Air Series
- Service footprint: strong Mid-Atlantic, Gulf Coast, Midwest
- Reputation: very strong data-center book of business, aggressive on energy efficiency
- Manufacturing: Maryland, Texas, others in US
- Private company

**BAC (Baltimore Aircoil Company)**
- HQ: Jessup, MD (some sources list Milford, DE — **[TOWER-13]** confirm)
- Founded: 1938 — invented closed-circuit induced-draft tower
- Flagship lines:
  - Open tower: Series 3000
  - Closed-circuit: FXV, HXV, Nexus
  - Adiabatic: PF4 and PFi Series
- Service footprint: national
- Reputation: closed-circuit pioneer; stainless Paradigm series for corrosion-sensitive sites
- Manufacturing: Maryland, Missouri, others in US
- Private equity-held (Amsted Industries, American-owned)

### §11.2  Second Tier — Worth Knowing

**Delta Cooling Towers** — Roxbury Township, NJ
- HDPE plastic construction, 20-year shell warranty
- Open tower only (not strong in closed-circuit or adiabatic)
- Strength: corrosion resistance for Gulf Coast, hurricane survivability
- Worth a quote on the open tower option only

**Tower Tech, Inc.** — Oklahoma City, OK
- Subsidiary of Creative Composites Group
- Modular tower systems
- Smaller footprint per ton due to patented design
- Niche player but real one

**Thermal Care** — Chicago area
- Industrial process cooling focus
- Includes adiabatic fluid coolers (HFCG line)
- Less common in data-center sector but grows

### §11.3  Vendor RFQ Logic

Issue one RFQ to SPX, EVAPCO, BAC with three architecture options per vendor:
- Option A: open tower, 1,500 RT at 80/85/97 °F Lafayette wet bulb
- Option B: closed-circuit fluid cooler, same duty
- Option C: adiabatic cooler, same duty with wet-mode hour projection

Delta Cooling Towers gets a single quote on the open tower for corrosion comparison.

Tower Tech gets a single quote on open tower for modular footprint comparison.

**9 primary bids + 2 alternate bids = 11 quotes total.** Evaluate on:
- 40% operational (lifecycle water, chemistry, maintenance cost)
- 25% technical (matches BROAD duty point, fouling factors, integration)
- 15% capital cost
- 10% lead time
- 10% service posture (named contractor, response time, spare parts)

### §11.4  Louisiana Service Representative Identification

Each vendor has a Louisiana-market manufacturer's rep. **[TOWER-14]** Identify and contact for pre-RFQ technical dialogue:
- SPX Cooling rep for LA/Gulf Coast
- EVAPCO rep for LA/Gulf Coast
- BAC rep for LA/Gulf Coast

Typical rep relationship: provides selection software access, does pre-RFQ sizing, escorts factory visit, handles post-sale service coordination.

---

## §12  LIFECYCLE AND SERVICE CONSIDERATIONS

### §12.1  Asset Life

- Open tower (PVC fill, galvanized steel structure): 15–20 years shell, 5–7 years fill
- Open tower (HDPE all-plastic construction, e.g. Delta): 25–30 years shell, 10+ years internal components
- Closed-circuit fluid cooler: 20–25 years coil, 5–7 years spray components
- Adiabatic cooler: 15–20 years coil, 2–5 years pads (replaceable consumable)

### §12.2  Refurbishment and Rebuild

- Year 5–7: fill replacement (open tower) or pad replacement (adiabatic)
- Year 10: drift eliminator replacement
- Year 15: major overhaul — fan, motor, bearings, structure inspection
- Year 20+: consider full replacement vs. rebuild

### §12.3  Total Cost of Ownership (20-year, indicative)

For 1,500 RT tower in LA (order of magnitude):

| Cost category                       | Open tower | Closed-circuit | Adiabatic |
|-------------------------------------|-----------:|---------------:|----------:|
| Capital (installed)                 | $250K      | $450K          | $600K     |
| Water (20 years at $6/kgal)         | $500K      | $500K          | $250K     |
| Chemicals (20 years)                | $300K      | $300K          | $80K      |
| Water treatment service (20 yr)     | $400K      | $400K          | $100K     |
| Electricity (20 yr at $0.08/kWh)    | $160K      | $180K          | $200K     |
| ASHRAE 188 program (20 yr)          | $400K      | $350K          | $150K     |
| Maintenance labor + parts (20 yr)   | $200K      | $250K          | $300K     |
| Rebuild / refurbish (year 10 + 15)  | $200K      | $250K          | $300K     |
| **TOTAL 20-YEAR TCO**               | **$2.41M** | **$2.68M**     | **$1.98M** |

(Numbers are order-of-magnitude and will be refined with vendor quotes. Take with a grain of salt until Rev 1.1.)

**Conclusion:** Over 20 years, **adiabatic wins on TCO in Louisiana** despite highest capital cost. Open tower is middle. Closed-circuit is the highest TCO — it has most of open tower's operating costs AND higher capital AND lower water savings than adiabatic.

This argues for reconsidering closed-circuit's "middle ground" position — it may be the worst-of-both-worlds choice unless process fluid protection is critically valued.

---

## §13  OPEN ITEMS AND RESEARCH QUESTIONS

| ID       | Item                                                                                   | Priority |
|----------|----------------------------------------------------------------------------------------|----------|
| TOWER-01 | Confirm LUS municipal water rates and blowdown sewer charges for Lafayette              | P-1      |
| TOWER-02 | Draft ASHRAE 188 Legionella program template for open-tower and closed-circuit scenarios | P-2   |
| TOWER-03 | Specify side-stream filtration architecture and cycle rate for open tower option        | P-2      |
| TOWER-04 | Confirm UV disinfection option availability and cost with each vendor                    | P-2      |
| TOWER-05 | Obtain Lafayette bin-hour wet/dry bulb data; model adiabatic wet-mode annual hours       | P-1      |
| TOWER-06 | Confirm available pad area per block at candidate Marlie 1 sites (for adiabatic footprint) | P-1    |
| TOWER-07 | Obtain OPC UA / Modbus register maps from each vendor — integration to Siemens S7-1500   | P-2      |
| TOWER-08 | Debate and lock operational scoring weights in research chat (Rev 1.1)                   | P-2      |
| TOWER-09 | Apply site-fit matrix to Marlie 1 parcel once LOI is signed                              | P-1      |
| TOWER-10 | SHPO preliminary consultation on Trappey's heat-rejection equipment massing              | P-1      |
| TOWER-11 | Parish well water option for Trappey's makeup water (vs. LUS extension)                  | P-2      |
| TOWER-12 | Draft SHPO consultation letter for Trappey's heat-rejection equipment placement          | P-2      |
| TOWER-13 | Confirm BAC current HQ address (Jessup MD vs. Milford DE)                                | P-3      |
| TOWER-14 | Identify and contact Louisiana manufacturer's rep for each of SPX, EVAPCO, BAC          | P-1      |

---

## §14  RECOMMENDED NEXT STEPS FOR THE RESEARCH CHAT

**Near-term (research chat phase):**

1. Run the Lafayette bin-hour analysis (**TOWER-05**) and rebuild adiabatic wet-mode projection.
2. Pull LUS water/sewer rates and rebuild 20-year TCO (**TOWER-01** → refresh §12.3 numbers).
3. Identify each vendor's Louisiana rep (**TOWER-14**) and draft pre-RFQ technical agenda.
4. Draft ASHRAE 188 program outline (**TOWER-02**) — this is a deliverable regardless of architecture choice, since open and closed-circuit both require it.
5. Build SHPO consultation letter for Trappey's (**TOWER-12**) — 4-week lead time for any SHPO response typically.

**Mid-term (before RFQ release):**

6. Write Cassette-TOWER-SPEC-001 as the formal specification (analogous to Cassette-ABS-CHLR-001 for the absorption chiller).
7. Finalize site-architecture fit for Marlie 1 once parcel is under LOI (**TOWER-09**).
8. Run the 9-cell × 11-bid competitive RFQ.

**Long-term:**

9. Negotiate Louisiana service tech assignment with winning bidder.
10. Integrate heat-rejection equipment operational data into the block-level BMS / OPC UA architecture.
11. Build the controls integration into Siemens S7-1500 (already planned for BROAD chiller; tower adds another Modbus slave or OPC UA device).

---

## APPENDIX A — OPERATIONAL CRITERIA GLOSSARY

- **Approach:** the temperature difference between the cooling tower's supply water (cold side) and the ambient design wet bulb. Lower = better. Typical: 5–7 °F for open, 7–9 °F for closed-circuit, 7–10 °F for adiabatic wet mode.
- **Range:** the temperature difference between supply and return water at the chiller. 12.5 °F for this duty.
- **Cycles of concentration:** the ratio of dissolved solids in the circulating water to the makeup water. Higher cycles = less blowdown but more scaling risk. Typical 3–5 in LA municipal water.
- **Drift:** fine water droplets that escape the drift eliminator. Measured as % of circulation flow. Modern units: 0.001%.
- **Plume:** visible water vapor condensing above the tower in cool air. Not drift — it's steam from hot water evaporation.
- **Blowdown:** water drained from the basin to control dissolved solids concentration. Goes to sewer.
- **Wet bulb:** the temperature an object would reach via evaporative cooling at a given humidity. The fundamental design temperature for evaporative cooling equipment.
- **ASHRAE 188-2021:** the US standard for Legionella management in building water systems. Requires a written water management program for any equipment that creates aerosolized water.
- **Adiabatic pre-cooling:** using water evaporation to reduce the dry-bulb temperature of air before it crosses a dry coil. "Adiabatic" here means the process adds water mass but doesn't change total heat content — it shifts sensible heat to latent heat and drops temperature.

---

## APPENDIX B — RFQ SPECIFICATION CHECKLIST

When Cassette-TOWER-SPEC-001 is drafted, each bid must have a definitive answer on:

### Thermal performance
- [ ] Cooling capacity at duty point (kW / RT)
- [ ] Approach to wet bulb at design
- [ ] Range (supply/return ΔT)
- [ ] LCWS outlet temperature (°F, ± tolerance)
- [ ] LCWR inlet temperature (°F)
- [ ] Flow rate (gpm) and pressure drop (ft H₂O)
- [ ] Wet-mode engagement hours annual (adiabatic only)
- [ ] Design wet bulb used for sizing (°F)
- [ ] Performance at 110% duty (part-load)
- [ ] Performance at 50% duty

### Physical
- [ ] Overall dimensions L × W × H (ft / mm)
- [ ] Weight (empty, operating, flooded)
- [ ] Required clearance all sides (ft)
- [ ] Air intake clearance / velocity
- [ ] Air discharge clearance
- [ ] Foundation loading spec (psf)

### Connections
- [ ] CWS / CWR flange size and class
- [ ] Process coil supply/return (closed-circuit, adiabatic)
- [ ] Makeup water inlet size
- [ ] Blowdown / overflow outlet size
- [ ] Drain outlet size and location
- [ ] Electrical feed (kW, voltage, phase)
- [ ] Emergency overflow routing

### Water
- [ ] Makeup water flow at design (gpm)
- [ ] Annual makeup water (gallons, Lafayette climate)
- [ ] Blowdown flow at design (gpm)
- [ ] Cycles of concentration target
- [ ] Water treatment chemicals required (type + consumption)
- [ ] Biocide program specification
- [ ] pH range
- [ ] Permitted LSI range

### Electrical and controls
- [ ] Fan motor specification (HP, voltage, efficiency class)
- [ ] VFD included or separate
- [ ] Spray pump motor (closed-circuit)
- [ ] Pad feed pump (adiabatic)
- [ ] Control system: modbus RTU / BACnet / LonWorks / proprietary
- [ ] OPC UA interface available? cost adder?
- [ ] Supply temperature setpoint control mode
- [ ] Ambient wet bulb sensor included?
- [ ] Drift eliminator rating
- [ ] Fire detection / alarm output

### Legionella and chemistry
- [ ] UV disinfection option (spray side)
- [ ] Chemical feed system integration
- [ ] Conductivity blowdown controller
- [ ] Sample port specification
- [ ] Drain down capability for off-season (not LA-critical)

### Construction
- [ ] Basin material (FRP / HDPE / stainless)
- [ ] Structural material (galvanized / stainless / HDPE)
- [ ] Hurricane tie-down / wind loading specification
- [ ] Corrosion warranty (years)
- [ ] Saltwater / coastal exposure rating

### Consumables
- [ ] Fill media replacement interval (years)
- [ ] Pad replacement interval (adiabatic, years)
- [ ] Drift eliminator replacement interval
- [ ] Coil cleaning interval

### Service
- [ ] Commissioning and startup service (included?)
- [ ] Training (hours, location)
- [ ] Recommended spare parts list (24-month kit)
- [ ] Louisiana service contractor assignment
- [ ] Response time SLA
- [ ] FAT protocol

### Commercial
- [ ] Base unit price (USD, FOB factory)
- [ ] Freight to Lafayette LA
- [ ] Installation supervision (USD)
- [ ] Standard warranty (duration, scope)
- [ ] Extended warranty 5-year (USD adder)
- [ ] Lead time from PO (weeks)
- [ ] Payment terms
- [ ] Lifecycle TCO estimate 20-year

### Certifications
- [ ] CTI (Cooling Technology Institute) certified performance
- [ ] ASME compliance
- [ ] ASHRAE 90.1 energy efficiency
- [ ] ASHRAE 188 Legionella management compatible
- [ ] UL listed
- [ ] Seismic zone certification

---

## APPENDIX C — LOUISIANA DESIGN-DAY WET BULB DATA (PLACEHOLDER)

**To be populated in Rev 1.1** after **TOWER-05** research chat.

Data sources to pull:
- ASHRAE Fundamentals Handbook, Chapter 14 (design conditions)
- NOAA local climatological data (LCD) for Lafayette Regional (KLFT)
- LADOTD climate data for design
- Adiabatic cooler bin-hour simulation tools (each vendor provides)

Target deliverable: annual duration curve showing hours at each wet bulb, dry bulb, and design-point combinations, to support precise adiabatic wet-mode hour projections.

---

**Cassette-TOWER-RSCH-001 — Heat Rejection Architecture Research Memo · Rev 1.0 · 2026-04-21**
**Scott Tomsu · scott@adc3k.com · (337) 780-1535 · Lafayette, Louisiana**
**CONFIDENTIAL · PRE-RFQ · SEED FOR FOLLOW-ON RESEARCH CHAT**
