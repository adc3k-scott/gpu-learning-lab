# MARLIE-COOL-RFQ-001 Rev 1.0
## Marlie 2.5 MW block — Vendor RFQ Call Sheets (Corrected)

**Scope:** Call sheets for EVAPCO, Alfa Laval (via HTS-LA), and Grundfos (via Premier Equipment).
**Status:** Ready to call. Corrected per MARLIE-COOL-001 Rev 1.0 engineering baseline.
**Prepared:** 2026-04-21 · Scott Tomsu · scott@adc3k.com · (337) 780-1535

---

## CALL #1 — EVAPCO (call this one first)
**EvapTech Gulf Services · (281) 529-6526**
5656 N. Sam Houston Pkwy E., Suite 170 — Houston, TX
evapco.com/data-center-cooling

**Tell them:**
> "I'm building a 2.5 megawatt liquid-cooled AI compute facility in Lafayette, Louisiana. I need an outdoor fluid cooler — specifically your EAW-DA Double Stack Adiabatic model. I need it to cool water that comes back to it at 110 degrees Fahrenheit and return it at 95 degrees Fahrenheit. The site design wet bulb temperature is 80 degrees Fahrenheit. I need a quote, a unit count, a footprint, and a lead time."

**Specs to give them if asked:**
| Parameter | Value |
|---|---|
| Duty | 2.6 MW (~745 RT / 750 tons) |
| Hot water in | 110°F |
| Cold water out | 95°F |
| Range | 15°F |
| Design wet bulb (Lafayette LA) | 80°F |
| Approach | 15°F |
| Water flow rate | ~1,190 gpm |
| Site | Lafayette, Louisiana — outdoor industrial pad |

**Questions to ask:**
1. How many EAW-DA units do I need to hit 2.6 MW at 80°F wet bulb?
2. Can we run two smaller units in parallel with shared headers, or is one extended unit preferred at this approach? What are the pros and cons?
3. What is the footprint of each unit?
4. Does the unit come with its own controls, or do I need a separate controller?
5. How does it connect to a building controls system? (Modbus? BACnet?)
6. What is the water-side pipe connection size?
7. What water treatment does the adiabatic pad system need for Louisiana water chemistry?
8. What is the total electrical load — breaker size and voltage I need to plan for?
9. What is current lead time?
10. Do you have a local service contractor in the Lafayette area?

**Ask them to send:**
- Selection report showing unit count and performance at Lafayette conditions
- Product datasheet for EAW-DA at your duty point
- Budget price per unit
- Lead time
- Electrical load summary (voltage, amps, breaker size)

---

## CALL #2 — Alfa Laval (plate-frame HX)
**Heat Transfer Specialists of Louisiana**
**(225) 292-6550 · sales@hts-la.com**
hts-la.com

**Tell them:**
> "I need a gasketed plate-and-frame heat exchanger — an Alfa Laval M15 — for a liquid cooling application. One side carries a propylene glycol-water mix at 25% glycol. The other side carries plain treated water. I need it to transfer 2.6 megawatts of heat. I need a selection report, plate count, delivery time, and budget price."

**Specs to give them if asked:**
| Parameter | Value |
|---|---|
| Duty | 2.6 MW (8,872,000 Btu/hr) |
| Hot side fluid | Propylene glycol 25% v/v (PG25) |
| Hot side in | 136°F |
| Hot side out | 113°F |
| Hot side flow | ~830 gpm |
| Cold side fluid | Treated water |
| Cold side in | 95°F |
| Cold side out | 110°F |
| Cold side flow | ~1,190 gpm |
| Design pressure | 145 psi (10 bar) both sides |
| Design temperature | 176°F (80°C) minimum |
| Plate material | AISI 316L stainless steel |
| Gasket material | EPDM |
| Connection size | DN150 (6") flanged, both sides |
| Installation | Outdoor industrial skid, Lafayette Louisiana |

**Questions to ask:**
1. Is the M15 the right frame for 2.6 MW at these conditions, or do you recommend a different model?
2. How many plates do I need?
3. Can the frame be ordered with room for 30% more plates so I can expand later without replacing the frame?
4. What plate series — M15-M, M15-B, or M15-BFG — is correct for this service?
5. Confirm EPDM gaskets are compatible with propylene glycol at 136°F peak.
6. Does it ship with frame, tie bars, and gaskets ready to bolt down on a skid?
7. What is current lead time?
8. Is there a Louisiana service technician for plate cleaning and re-gasketing support?

**Ask them to send:**
- Selection report confirming M15 at your duty point (plate count, series, UA)
- Confirmation of EPDM + 316L for PG25 service
- Budget price
- Lead time

---

## CALL #3 — Grundfos pumps
**Premier Equipment Corp.**
**(225) 755-2240 · 1-800-752-7107**
13918 Airline Hwy, Baton Rouge, LA 70817
premierequipla.com

**Tell them:**
> "I need vertical multistage centrifugal pumps — Grundfos CRE series — for a liquid cooling skid. I need two sets: one set moves a propylene glycol-water mix, the other set moves plain water. All pumps need variable frequency drives built in. I need three of each — two running at a time, one spare on standby. I need a selection confirmation, budget price, and lead time."

### Set A — PG25 glycol pumps

**Specs to give them:**
| Parameter | Value |
|---|---|
| Fluid | Propylene glycol 25% v/v, SG 1.012 |
| Fluid temperature | ~125°F (51°C) average |
| Flow per pump | ~415 gpm (94 m³/hr) — 2 pumps running in parallel |
| Total system flow | ~830 gpm |
| Head | 100 ft TDH (3.0 bar, 30.5 m) |
| Qty | 3 (2 active + 1 standby, N+1) |
| Voltage | 480V 3-phase |

**Questions — Set A:**
1. Is the Grundfos CRE 90 the right model at 94 m³/hr and 30 m TDH? What is near BEP?
2. Does propylene glycol 25% require any special seal or impeller material on the CRE?
3. Does the CRE come with the VFD integrated, or is that a separate purchase?
4. What is the electrical draw per pump at this duty point?

### Set B — FW water pumps

**Specs to give them:**
| Parameter | Value |
|---|---|
| Fluid | Treated water (no glycol) |
| Fluid temperature | ~103°F (39°C) average |
| Flow per pump | ~595 gpm (135 m³/hr) — 2 pumps running in parallel |
| Total system flow | ~1,190 gpm |
| Head | 80 ft TDH (2.4 bar, 24.4 m) |
| Qty | 3 (2 active + 1 standby, N+1) |
| Voltage | 480V 3-phase |

**Questions — Set B:**
1. Is the Grundfos CRE 125 the right model at 135 m³/hr and 24 m TDH?
2. At 595 gpm per pump, would an end-suction NKE pump (e.g. NKE 80-200) be more efficient than vertical multistage? **Please quote both options.**
3. What is the electrical draw per pump at this duty point?

### Both sets:
1. Can you support commissioning in Lafayette if needed?
2. Do you stock these locally or are they factory order?
3. What is current lead time?

**Ask them to send:**
- Pump selection reports for both sets at stated duty points
- Confirmation of glycol-compatible seal package for Set A
- Budget price per pump including VFD
- Lead time
- Both CRE 125 and NKE option for Set B

---

## Revision history

| Rev | Date | Change |
|---|---|---|
| 1.0 | 2026-04-21 | Initial issue. Corrected per MARLIE-COOL-001 Rev 1.0: PG25 pump from CRE-64 to CRE-90; FW pump from CRE-45 to CRE-125/NKE; PG25 head from 5.5 bar to 3.0 bar; FW flow from 2,900 LPM to 4,500 LPM; Alfa Laval flows updated to 830 gpm / 1,190 gpm; EVAPCO unit count question added. |
